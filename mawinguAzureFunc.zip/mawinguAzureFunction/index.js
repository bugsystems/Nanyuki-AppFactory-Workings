let https = require('https');
//set these values to retrieve the oauth token
let crmOrg = 'https://nanyukiappfactory.api.crm4.dynamics.com';
let clientId = '281fb603-6abe-4079-8650-258e34ae1fe1';
let clientSecret = 'sVDdLx20iW7SI0tIT2n+QVnWkVJ2SPVn/GX3qBSrNhY=';
let tokenEndPoint = 'https://login.microsoftonline.com/afdf297f-b713-45ce-a072-eca2a0ec0533/oauth2/token';

let name;

//crm api host
let crmWebApiHost = 'nanyukiappfactory.api.crm4.dynamics.com';

module.exports = function(context, req) {
    //get customer details
    name = req.query.name;
    context.log(name);

    //authorization endpoint host name
    let authHost = 'login.microsoftonline.com';
    context.log(authHost);

    //authorization endpoint path
    let authPath = '/afdf297f-b713-45ce-a072-eca2a0ec0533/oauth2/token';
    context.log(authPath);

    //authorization request string
    let requestString = 'client_id=' + encodeURIComponent(clientId);
    requestString += '&resource=' + encodeURIComponent(crmOrg);
    requestString += '&client_secret=' + encodeURIComponent(clientSecret);
    requestString += '&grant_type=client_credentials';

    //set the token request parameters
    let tokenRequestParameters = {
        host: authHost,
        path: authPath,
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': requestString.length
        }
    };

    //Request for token
    context.log('starting token request');
    let tokenRequest = https.request(tokenRequestParameters, function(response) {

        //variable that will hold result
        let responseResult = '';

        response.on('data', function(result) {
            //result
            responseResult += result;
        });

        response.on('end', function() {

            context.log('token response retrieved');

            //JSON parse the response 
            let tokenResponse = JSON.parse(responseResult);

            //extract the token
            let token = tokenResponse.access_token;
            context.log(token);

            //pass the token to the function that queries dynamics
            getData(context, token);
        });
    });

    tokenRequest.on('error', function(e) {
        context.error(e);
        context.done();
    });

    //post the token request data
    tokenRequest.write(requestString);

    //close the token request
    tokenRequest.end();
}

function getData(context, token) {

    let crmWebApiQueryPath = "/api/data/v9.0/accounts?$select=name,telephone1&$filter=contains(name,\'" + name + "\')";
    context.log(crmWebApiQueryPath);

    //set the web api request headers
    let requestHeaders = {
        'Authorization': 'Bearer ' + token,
        'OData-MaxVersion': '4.0',
        'OData-Version': '4.0',
        'Accept': 'application/json',
        'Content-Type': 'application/json; charset=utf-8',
        'Prefer': 'odata.maxpagesize=500',
        'Prefer': 'odata.include-annotations=OData.Community.Display.V1.FormattedValue'
    };

    //set the crm request parameters
    let crmRequestParameters = {
        host: crmWebApiHost,
        path: crmWebApiQueryPath,
        method: 'GET',
        headers: requestHeaders
    };

    context.log(crmRequestParameters.path);

    //make the web api request
    context.log('starting data request');
    let crmRequest = https.request(crmRequestParameters, function(response) {
        let responseData = "";

        response.on('data', function(result) {
            responseData += result;
        });


        response.on('end', function() {
            let customers = JSON.parse(responseData).value;

            context.log(customers);

            context.res = {
                body: customers
            };
            context.done();
        });
    });

    crmRequest.on('error', function(error) {
        context.error(error);
        context.done();
    });

    //close the web api request
    crmRequest.end();
}